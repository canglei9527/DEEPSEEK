F28P55x 全外设 DriverLib API 函数指南（中文离线版）

版本：TI 在线指南标注 v5.04.00.00
入口：打开 index.html

中文化范围：通用说明、编程模型、CCS 使用说明、全部外设模块概览、导航与常见字段标签。已将适合阅读的外设 API 注释、参数说明和枚举说明译为中文；函数名、参数名、宏/枚举标识符及代码示例保持原样，便于对照 TI 官方定义。

英文原版：../F28P55x_DriverLib_API_Guide_v5.04.00.00/index.html
TI 官方来源：https://software-dl.ti.com/C2000/docs/C2000_driverlib_api_guide/f28p55x/build/html/index.html
